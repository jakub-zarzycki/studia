# Testy do zadania Sortowanie topologiczne.

- Testy należy dodawać do katalogu tests. W postaci kodu źródłowego ocaml wykorzystującego bibliotekę `Topol` i wypisującego na `stderr` informacje o wykrytych problemach.
- Aby użyć skryptu `testuj.sh` do weryfikacji tetsów należy umieścić swój program w katalogu ze skryptem w pliku `topol.ml` i uruchomić skrypt
