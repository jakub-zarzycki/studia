# Testy do zadania Modyfikacja drzew.

- Testy należy dodawać do katalogu [`tests`](https://gitlab.com/MIMUW-wpf/testy-iset/tree/master/tests). W postaci kodu źródłowego ocaml wykorzystującego bibliotekę `ISet` i wypisującego na `stderr` informacje o wykrytych problemach.
- Aby użyć skryptu `testuj.sh` do weryfikacji testów należy umieścić swój program w katalogu ze skryptem w pliku `iSet.ml` i uruchomić skrypt.
